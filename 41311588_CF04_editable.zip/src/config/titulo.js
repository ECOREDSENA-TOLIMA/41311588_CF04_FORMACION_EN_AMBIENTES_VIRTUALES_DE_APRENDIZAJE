module.exports =
  'Evaluación del proceso formativo en el LMS, según orientaciones institucionales'
