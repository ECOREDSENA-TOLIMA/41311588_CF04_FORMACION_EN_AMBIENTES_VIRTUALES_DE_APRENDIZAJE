<template lang="pug">
.curso-main-container.pb-3
  BannerInterno
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5
    .titulo-principal.color-acento-contenido(data-aos="flip-up")
      .titulo-principal__numero
        span 2
      h1 Momento de cierre de la formación virtual
    
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12(data-aos="flip-up")
        figure
          img(src='@/assets/curso/temas/tema2/img1.png', alt='Imagen decorativa')
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12(data-aos="fade-left") 
        p En el proceso de cierre de la formación virtual, siempre se debe tener como ayuda las herramientas que ofrece el LMS SENA y a través de ellas, poder aplicar unos correctos juicios evaluativos y realizar reportes sobre las acciones llevadas a cabo durante todo el curso.

    separador
    
    #t_2_1.titulo-segundo.color-acento-contenido(data-aos="flip-up")
      h2 2.1 Juicios evaluativos
    
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-10
        .cajon.color-primario.cajon2.p-4
          .row.justify-content-center.align-items-center
            .col-lg-2
              figure
                img(src='@/assets/curso/temas/tema2/img2.svg', alt='Imagen decorativa')
            .col-lg-10
              p.mb-4 Los juicios evaluativos son los que se emiten al finalizar cada resultado de aprendizaje, estos juicios en la formación SENA se emiten con letra A: Aprobado y D: No aprobado.
              p.mb-0 Los juicios evaluativos son el resultado de la evaluación de cada una de las evidencias de aprendizaje entregadas por el aprendiz. Se otorga un juicio evaluativo por cada resultado de aprendizaje. Por ello, es importante conocer el proceso de evaluación de las diferentes evidencias programadas. A continuación, se presenta por medio de diferentes videos, cómo realizar dicho procedimiento en el LMS SENA:
    
    .titulo.mb-5(data-aos="flip-up")
      img(src='@/assets/curso/temas/ico.svg', alt='Imagen decorativa')
      h4.mb-0 Evaluar evidencias de aprendizaje

    figure.mb-5(data-aos="zoom-in")
      .video
        iframe(width="560" height="315" src="https://www.youtube.com/embed/2OV4frqJMJQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen)

    .titulo.mb-5(data-aos="flip-up")
      img(src='@/assets/curso/temas/ico.svg', alt='Imagen decorativa')
      h4.mb-0 Evaluar Foro

    figure.mb-5(data-aos="zoom-in")
      .video
        iframe(width="560" height="315" src="https://www.youtube.com/embed/zEDza_7h2Qc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen)
    
    .titulo.mb-5(data-aos="flip-up")
      img(src='@/assets/curso/temas/ico.svg', alt='Imagen decorativa')
      h4.mb-0 Evaluar Wiki

    figure.mb-5(data-aos="zoom-in")
      .video
        iframe(width="560" height="315" src="https://www.youtube.com/embed/UvUVWO3d6OY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen)

    .titulo.mb-5(data-aos="flip-up")
      img(src='@/assets/curso/temas/ico.svg', alt='Imagen decorativa')
      h4.mb-0 Juicios evaluativos
    
    .row.bg--gradientBlue.mb-4
      .col-10
        .row.justify-content-center.align-items-center.mb-3(style="margin-inline:3em;")
          .col-lg-4.col-8.mb-lg-0.mb-4(data-aos="zoom-in")
            figure
              img(src='@/assets/curso/temas/tema2/img5.svg', alt='Imagen decorativa')
          .col-lg-8.mb-lg-0.mb-4(data-aos="fade-right")
            p El proceso para la emisión de los juicios evaluativos lo realiza el instructor en la herramienta del Centro de Calificaciones del LMS o a través del sistema de SOFIA Plus.
            p Cuando se registran los juicios evaluativos de los resultados de aprendizaje, el sistema SOFIA Plus procederá a cambiar el estado del aprendiz de “en formación” a “por certificar”, esta situación no le permitirá al aprendiz ingresar nuevamente al programa de formación. En este sentido, se recomienda que el instructor realice el proceso de valoración por juicios evaluativos en el momento de realizar el cierre del curso.


    separador
    
    #t_2_2.titulo-segundo.color-acento-contenido(data-aos="flip-up")
      h2 2.2 Acciones al finalizar el curso
    
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12(data-aos="fade-left") 
        p Para tener claridad sobre los procedimientos que debe tener en cuenta al momento de finalizar el curso, se invita a que analice el siguiente video, el cual explica de manera puntual todas estas acciones a seguir, por medio del LMS:
    
    figure.mb-5(data-aos="zoom-in")
      .video
        iframe(width="560" height="315" src="https://www.youtube.com/embed/9wHrAU0Qzoc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen)

    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12(data-aos="fade-left") 
        p Así como se evidencian los resultados del aprendizaje alcanzados por el aprendiz, también se evidencia la efectividad del rol del instructor durante todo el proceso de ejecución de la formación virtual, en cada uno de los momentos del curso, en relación al cumplimiento de sus funciones. Esta efectividad se mide a través de una lista de chequeo, cuyos resultados se dan a conocer al instructor al finalizar el curso.

    
    separador
    
    #t_2_3.titulo-segundo.color-acento-contenido(data-aos="flip-up")
      h2 2.3 Seguimiento y reportes
    
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-4(data-aos="zoom-in")
        figure
          img(src='@/assets/curso/temas/tema2/img3.png', alt='Imagen decorativa')

      .col-lg-8
        p Una de las principales acciones en el momento de cierre del curso es generar informes o reportes sobre las diferentes acciones realizadas durante el programa de formación, ya sea por parte del aprendiz o el instructor. A continuación, se muestra el procedimiento para esta acción, por medio del video que se relaciona, seguido de estas dos apreciaciones:
        .row.justify-content-center.align-items-center
          .col-lg-12(data-aos="flip-up")
            .cajon.color-primario.cajon2.p-3
              .row.justify-content-center.align-items-center
                .col-3
                  figure
                    img(src='@/assets/curso/temas/tema2/img4.svg', alt='Imagen decorativa')
                .col-9
                  ul.lista-ul
                    li
                      i.fas.fa-check
                      | Los reportes pueden generarse desde SOFIA Plus.
                    li
                      i.fas.fa-check
                      | En SOFIA Plus se genera el reporte de juicios evaluativos.
    
    .titulo.mb-5(data-aos="flip-up")
      img(src='@/assets/curso/temas/ico.svg', alt='Imagen decorativa')
      h4.mb-0 Reportes del curso 
      
    figure.mb-5(data-aos="zoom-in")
      .video
        iframe(width="560" height="315" src="https://www.youtube.com/embed/-gYl-1sp7Bc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen)

</template>

<script>
export default {
  name: 'Tema2',
  data: () => ({
    // variables de vue
  }),
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
  updated() {
    this.$aosRefresh()
  },
}
</script>

<style lang="sass"></style>
